%TF.GenerationSoftware,KiCad,Pcbnew,10.0.8*%
%TF.CreationDate,2026-11-02T17:32:07+01:00*%
%TF.ProjectId,petster-27c128-daughterboard,70657473-7465-4722-9d32-37633132382d,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.8) date 2026-11-02 17:32:07*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
